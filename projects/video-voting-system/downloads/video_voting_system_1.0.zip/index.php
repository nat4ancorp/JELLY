<?php
ob_start(); //Initiate the output buffer
?>
<!--
Video Voting System (VVS) Core
Copyright © 2012 Nat4ancorp
Original coding work done by: Nathan Smyth
A project written and coded by Nathan Smyth and available as a free software to be used 
by anyone who needs it and can be modified to your liking. I just created the base, you
can now make it how you want but please retain this copyright and original coding info
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php
/* add configuration files */
include 'conf/props.php';

/* create a new instance of the properties class */
$properties=new properties();

/* connect to the database via including the config connect file */
include 'conf/connect.php';

/* get the user's IP */
$ip=$_SERVER['REMOTE_ADDR'];

/* create a variable - session by taking the IP and randomizing a 14 digit shuffled number */
$session=str_shuffle($ip.rand("000000000000000","999999999999999"));

/* PUT HARMLESS SESSION COOKIE FOR LOGGING TO EXPIRE IN 20 YEARS */
/* STEP 1: FIRST FIND EXISTING COOKIE IN DATABASE */
if(isset($_COOKIE['vv_session'])){$session_stored=$_COOKIE['vv_session'];}else{$session_stored="";}
$FIND_SESSION=mysql_query("SELECT * FROM {$properties->DB_PREFIX}who WHERE ip='$ip' AND session='$session_stored'");
if(mysql_num_rows($FIND_SESSION)<1){
	/* NO SESSION; CLEAR STRAGLERS (UNSET SESSION) */
	setcookie("vv_session","",time()-(20 * 365 * 24 * 60 * 60));
	/* STEP 2: SET NEW COOKIE */
	setcookie("vv_session",$session,time()+(20 * 365 * 24 * 60 * 60));
	/* STEP 3: INSERT LOGGED INFO */
	mysql_query("INSERT INTO {$properties->DB_PREFIX}who (ip,session,has_voted_times) VALUES ('$ip','$session','0')") or die('Error: '.mysql_error());
} else {
	/* SESSION FOUND; USE IT AND DONT SET NEW ONE */
}
?>

<head>
<meta name="description" content="" />
<meta name="author" content=">" />
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<script type="text/javascript" src="js/jQuery/jquery.js"></script>
<script type="text/javascript" src="js/jQuery/jquery-ui.js"></script>
<script type="text/javascript" src="js/JWPlayer/embed/swfobject.js"></script>
<script type='text/javascript' src='js/JWPlayer/jwplayer.js'></script>
<script type="text/javascript" src="js/jRating/jRating.jquery.js"></script>
<script type="text/javascript" src="js/jRating/jNotify.jquery.js"></script>
<script type="text/javascript" src="js/general.js"></script>

<link rel="stylesheet" href="css/jRating/jRating.jquery.css" type="text/css" media="screen" />
<link rel="stylesheet" href="css/jRating/jNotify.jquery.css" type="text/css" />
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.1/themes/base/jquery-ui.css" />
<link rel="stylesheet" href="css/general.css" />
<title>Video Voting System 1.0</title>
<?php
/* assign the JWPlayer Premium if you have one; NOTE: Don't place actual key here, place in conf/props.php file */
?><script type="text/javascript">jwplayer.key="<?php echo $properties->JW_LICENSE;?>";</script>
</head>
<body>
<center>
<?php
if(isset($_GET['page'])){
	switch($_GET['page']){
		case 'admin':
			/* DETECT LOGIN */
			if(isset($_COOKIE['vv_admin_session'])){
				/* LOGGED SESSION */
				
				/* GET THE DETAILS */
				$GET_USER_DETAILS=mysql_query("SELECT * FROM {$properties->DB_PREFIX}admins WHERE logged_in='yes' AND logged_ip='$ip' AND logged_session='".$_COOKIE['vv_admin_session']."'");
				if(mysql_num_rows($GET_USER_DETAILS)<1){
					/* COOKIE AND IP DOES NOT MATCH IN DB; USER MAY HAVE TAMPERED WITH COOKIE */
					$logged_in="no";
				} else {
					/* USER FOUND BY COOKIE AND IP; CHECK FOR status */
					while($FETCH_USER_DETAILS=mysql_fetch_array($GET_USER_DETAILS)){
						$status=$FETCH_USER_DETAILS['status'];
						$username_logged=$FETCH_USER_DETAILS['uname'];
					}
					switch($status){
						case 'active':
							/* USER IS ACTIVE */
							$logged_in="yes";
						break;
						
						case 'suspended':
							/* USER IS SUSPENDED */
							$logged_in="no";
						break;
						
						case 'deleted':
							/* USER DOES NOT EXIST */
							$logged_in="no";
						break;
						
						case 'pending':
							/* USER IS PENDING */
							$logged_in="no";
						break;
					}
					
				}
			} else {
				/* NO SESSION LOGGED; DISPLAY LOGIN */
				$logged_in="no";	
			}

			if($logged_in == "yes"){
				if(isset($_POST['logout'])){
					$username=$_POST['username_logged'];
					/* USER REQUEST TO LOG OUT */
					/* DELETE COOKIE */
					$adminsession=$_COOKIE['vv_admin_session'];
					setcookie("vv_admin_session",$adminsession,time()-(20 * 365 * 24 * 60 * 60));
							
					/* STEP 4: POST UPDATE */
					mysql_query("UPDATE {$properties->DB_PREFIX}admins SET logged_in='no' WHERE uname='$username'");
					mysql_query("UPDATE {$properties->DB_PREFIX}admins SET logged_session='' WHERE uname='$username'");
					mysql_query("UPDATE {$properties->DB_PREFIX}admins SET logged_ip='' WHERE uname='$username'");
					
					/* STEP 5: POST MESSAGE */
					?>
                    <div class="admin-response-success">You have successfully been logged out.<br /><a href="<?php echo $properties->WEB_URL?>?page=admin">Go home</a></div>
                    <?php
				} else {
					?>
					<h1><a href="<?php echo $properties->WEB_URL;?>" style="text-decoration:none;"> < </a> <a href="<?php echo $properties->WEB_URL;?>?page=admin"><?php echo $properties->TITLE;?>'s Administration Panel</a></h1>
					<form method="post" action="">
                    <input type="hidden" name="username_logged" value="<?php echo $username_logged;?>" />
						<input type="submit" name="logout" value="Logout">
					</form>
                    <br />
                    <div class="admin-table no-border">
                        <div class="admin-tablerow">
                            <div class="admin-tablerow1coltop">
                                Name
                            </div>
                            <div class="admin-tablerow2coltop">
                                Source
                            </div>
                            <div class="admin-tablerow3coltop">
                                Type
                            </div>
                            <div class="admin-tablerow4coltop">
                                Votes
                            </div>
                            <div class="admin-tablerow5coltop">
                                Rate
                            </div>
                            <div class="admin-tablerow6coltop">
                                Status
                            </div>
                        </div>
                    </div>
					<h2>Active Video Entries</h2>
						<?php
						if(isset($_POST['_changer'])){
							
						} else {
							/* find and list all entries */
							$FIND_ALL_ENTRIES2=mysql_query("SELECT * FROM {$properties->DB_PREFIX}entries WHERE status='active' ORDER BY name");
							if(@mysql_num_rows($FIND_ALL_ENTRIES2)<1){
								?>
								No entries found...
								<?php
							} else {
								?>
								<div class="admin-table">
								<?php
								while($FETCH_ALL_ENTRIES2=mysql_fetch_array($FIND_ALL_ENTRIES2)){
									?>
									<div class="admin-tablerow">
										<div class="admin-tablerow1col">
											<input type="hidden" id="placeholder-currentName-<?php echo $FETCH_ALL_ENTRIES2['id'];?>" value="<?php echo $FETCH_ALL_ENTRIES2['name'];?>" />
											<div class="placeholder-link" id="placeholder-name-<?php echo $FETCH_ALL_ENTRIES2['id'];?>">
												<?php if(strlen($FETCH_ALL_ENTRIES2['name'])>25){echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'name','focus')\" title=\"".$FETCH_ALL_ENTRIES2['name']."\">".substr($FETCH_ALL_ENTRIES2['name'],0,25)."...</a>";}else{echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'name','focus')\">".$FETCH_ALL_ENTRIES2['name']."</a>";}?>
											</div>							
										</div>
										<div class="admin-tablerow2col">
											<input type="hidden" id="placeholder-currentSource-<?php echo $FETCH_ALL_ENTRIES2['id'];?>" value="<?php echo $FETCH_ALL_ENTRIES2['source'];?>" />
											<div class="placeholder-link" id="placeholder-source-<?php echo $FETCH_ALL_ENTRIES2['id'];?>">
												<?php if(strlen($FETCH_ALL_ENTRIES2['source'])>29){echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'source','focus')\" title=\"".$FETCH_ALL_ENTRIES2['source']."\">".substr($FETCH_ALL_ENTRIES2['source'],0,29)."...</a>";}else{echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'source','focus')\">".$FETCH_ALL_ENTRIES2['source']."</a>";}?>
											</div>
										</div>
										<div class="admin-tablerow3col">
											<input type="hidden" id="placeholder-currentType-<?php echo $FETCH_ALL_ENTRIES2['id'];?>" value="<?php echo $FETCH_ALL_ENTRIES2['type'];?>" />
											<div class="placeholder-link" id="placeholder-type-<?php echo $FETCH_ALL_ENTRIES2['id'];?>">
												<?php if(strlen($FETCH_ALL_ENTRIES2['type'])>29){echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'type','focus')\" title=\"".$FETCH_ALL_ENTRIES2['type']."\">".substr($FETCH_ALL_ENTRIES2['type'],0,29)."...</a>";}else{echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'type','focus')\">".$FETCH_ALL_ENTRIES2['type']."</a>";}?>
											</div>
										</div>
										<div class="admin-tablerow4col">
											<?php echo $FETCH_ALL_ENTRIES2['totalvotes'];?>
										</div>
										<div class="admin-tablerow5col">
											<?php echo $FETCH_ALL_ENTRIES2['rate'];?>
										</div>
										<div class="admin-tablerow6col">
											<select name="_changer" onChange="save('<?php echo $FETCH_ALL_ENTRIES2['id'];?>',this.value)">
												<?php
												if($FETCH_ALL_ENTRIES2['status']=="active"){?><option value="active" selected="selected" disabled="disabled">Active</option><?php }else{?><option value="active">Active</option><?php }
												
												if($FETCH_ALL_ENTRIES2['status']=="inactive"){?><option value="inactive" selected="selected" disabled="disabled">Inactive</option><?php }else{?><option value="inactive">Inactive</option><?php }
												
												if($FETCH_ALL_ENTRIES2['status']=="deleted"){?><option value="deleted" selected="selected" disabled="disabled">Deleted</option><?php }else{?><option value="deleted">Deleted</option><?php }
												
												?>
											</select>
										</div>
									</div>
									<?php
								}
							}	
						}
						?>
					</div>
	
					<h2>Inactive Video Entries</h2>
						<?php
						/* find and list all entries */
						$FIND_ALL_ENTRIES2=mysql_query("SELECT * FROM {$properties->DB_PREFIX}entries WHERE status='inactive' ORDER BY name");
						if(@mysql_num_rows($FIND_ALL_ENTRIES2)<1){
							?>
							No entries found...
							<?php
						} else {
							?>
							<div class="admin-table">
							<?php
							while($FETCH_ALL_ENTRIES2=mysql_fetch_array($FIND_ALL_ENTRIES2)){
								?>
								<div class="admin-tablerow" id="draggable-<?php echo $FETCH_ALL_ENTRIES2['id'];?>">
									<div class="admin-tablerow1col">
										<input type="hidden" id="placeholder-currentName-<?php echo $FETCH_ALL_ENTRIES2['id'];?>" value="<?php echo $FETCH_ALL_ENTRIES2['name'];?>" />
										<div class="placeholder-link" id="placeholder-name-<?php echo $FETCH_ALL_ENTRIES2['id'];?>">
											<?php if(strlen($FETCH_ALL_ENTRIES2['name'])>25){echo "<a title=\"".$FETCH_ALL_ENTRIES2['name']."\">".substr($FETCH_ALL_ENTRIES2['name'],0,25)."...</a>";}else{echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'name','focus')\">".$FETCH_ALL_ENTRIES2['name']."</a>";}?>
										</div>							
									</div>
									<div class="admin-tablerow2col">
										<input type="hidden" id="placeholder-currentSource-<?php echo $FETCH_ALL_ENTRIES2['id'];?>" value="<?php echo $FETCH_ALL_ENTRIES2['source'];?>" />
										<div class="placeholder-link" id="placeholder-source-<?php echo $FETCH_ALL_ENTRIES2['id'];?>">
											<?php if(strlen($FETCH_ALL_ENTRIES2['source'])>29){echo "<a title=\"".$FETCH_ALL_ENTRIES2['source']."\">".substr($FETCH_ALL_ENTRIES2['source'],0,29)."...</a>";}else{echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'source','focus')\">".$FETCH_ALL_ENTRIES2['source']."</a>";}?>
										</div>
									</div>
									<div class="admin-tablerow3col">
										<input type="hidden" id="placeholder-currentType-<?php echo $FETCH_ALL_ENTRIES2['id'];?>" value="<?php echo $FETCH_ALL_ENTRIES2['type'];?>" />
										<div class="placeholder-link" id="placeholder-type-<?php echo $FETCH_ALL_ENTRIES2['id'];?>">
											<?php if(strlen($FETCH_ALL_ENTRIES2['type'])>29){echo "<a title=\"".$FETCH_ALL_ENTRIES2['type']."\">".substr($FETCH_ALL_ENTRIES2['type'],0,29)."...</a>";}else{echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'type','focus')\">".$FETCH_ALL_ENTRIES2['type']."</a>";}?>
										</div>
									</div>
									<div class="admin-tablerow4col">
										<?php echo $FETCH_ALL_ENTRIES2['totalvotes'];?>
									</div>
									<div class="admin-tablerow5col">
										<?php echo $FETCH_ALL_ENTRIES2['rate'];?>
									</div>
                                    <div class="admin-tablerow6col">
										<select name="_changer" onChange="save('<?php echo $FETCH_ALL_ENTRIES2['id'];?>',this.value)">
                                        	<?php
											if($FETCH_ALL_ENTRIES2['status']=="active"){?><option value="active" selected="selected" disabled="disabled">Active</option><?php }else{?><option value="active">Active</option><?php }
											
											if($FETCH_ALL_ENTRIES2['status']=="inactive"){?><option value="inactive" selected="selected" disabled="disabled">Inactive</option><?php }else{?><option value="inactive">Inactive</option><?php }
											
											if($FETCH_ALL_ENTRIES2['status']=="deleted"){?><option value="deleted" selected="selected" disabled="disabled">Deleted</option><?php }else{?><option value="deleted">Deleted</option><?php }
											
											?>
                                        </select>
									</div>
								</div>
								<?php
							}
						}
						?>
					</div>
	
					<h2>Deleted Video Entries</h2>
						<?php
						/* find and list all entries */
						$FIND_ALL_ENTRIES2=mysql_query("SELECT * FROM {$properties->DB_PREFIX}entries WHERE status='deleted' ORDER BY name");
						if(@mysql_num_rows($FIND_ALL_ENTRIES2)<1){
							?>				
							No entries found...
							<?php
						} else {
							?>
							<div class="admin-table">
							<?php
							while($FETCH_ALL_ENTRIES2=mysql_fetch_array($FIND_ALL_ENTRIES2)){
								?>
								<div class="admin-tablerow">
									<div class="admin-tablerow1col">
										<input type="hidden" id="placeholder-currentName-<?php echo $FETCH_ALL_ENTRIES2['id'];?>" value="<?php echo $FETCH_ALL_ENTRIES2['name'];?>" />
										<div class="placeholder-link" id="placeholder-name-<?php echo $FETCH_ALL_ENTRIES2['id'];?>">
											<?php if(strlen($FETCH_ALL_ENTRIES2['name'])>25){echo "<a title=\"".$FETCH_ALL_ENTRIES2['name']."\">".substr($FETCH_ALL_ENTRIES2['name'],0,25)."...</a>";}else{echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'name','focus')\">".$FETCH_ALL_ENTRIES2['name']."</a>";}?>
										</div>							
									</div>
									<div class="admin-tablerow2col">
										<input type="hidden" id="placeholder-currentSource-<?php echo $FETCH_ALL_ENTRIES2['id'];?>" value="<?php echo $FETCH_ALL_ENTRIES2['source'];?>" />
										<div class="placeholder-link" id="placeholder-source-<?php echo $FETCH_ALL_ENTRIES2['id'];?>">
											<?php if(strlen($FETCH_ALL_ENTRIES2['source'])>29){echo "<a title=\"".$FETCH_ALL_ENTRIES2['source']."\">".substr($FETCH_ALL_ENTRIES2['source'],0,29)."...</a>";}else{echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'source','focus')\">".$FETCH_ALL_ENTRIES2['source']."</a>";}?>
										</div>
									</div>
									<div class="admin-tablerow3col">
										<input type="hidden" id="placeholder-currentType-<?php echo $FETCH_ALL_ENTRIES2['id'];?>" value="<?php echo $FETCH_ALL_ENTRIES2['type'];?>" />
										<div class="placeholder-link" id="placeholder-type-<?php echo $FETCH_ALL_ENTRIES2['id'];?>">
											<?php if(strlen($FETCH_ALL_ENTRIES2['type'])>29){echo "<a title=\"".$FETCH_ALL_ENTRIES2['type']."\">".substr($FETCH_ALL_ENTRIES2['type'],0,29)."...</a>";}else{echo "<a onclick=\"edit(".$FETCH_ALL_ENTRIES2['id'].",'type','focus')\">".$FETCH_ALL_ENTRIES2['type']."</a>";}?>
										</div>
									</div>
									<div class="admin-tablerow4col">
										<?php echo $FETCH_ALL_ENTRIES2['totalvotes'];?>
									</div>
									<div class="admin-tablerow5col">
										<?php echo $FETCH_ALL_ENTRIES2['rate'];?>
									</div>
                                    <div class="admin-tablerow6col">
										<select name="_changer" onChange="save('<?php echo $FETCH_ALL_ENTRIES2['id'];?>',this.value)">
                                        	<?php
											if($FETCH_ALL_ENTRIES2['status']=="active"){?><option value="active" selected="selected" disabled="disabled">Active</option><?php }else{?><option value="active">Active</option><?php }
											
											if($FETCH_ALL_ENTRIES2['status']=="inactive"){?><option value="inactive" selected="selected" disabled="disabled">Inactive</option><?php }else{?><option value="inactive">Inactive</option><?php }
											
											if($FETCH_ALL_ENTRIES2['status']=="deleted"){?><option value="deleted" selected="selected" disabled="disabled">Deleted</option><?php }else{?><option value="deleted">Deleted</option><?php }
											
											?>
                                        </select>
									</div>
								</div>
								<?php
							}
						}
						?>
					</div>
                    
                    <h2>Add an entry</h2>
                    <?php
					if(isset($_POST['entry_save'])){
						/* SAVING ENTRY */
						$error_console="";
						
						/* STEP 1: GET DATA */
						$entry_name=$_POST['entry_name'];
						$entry_type=$_POST['entry_type'];
						$entry_source=$_POST['entry_source'];
						$entry_originator=$_POST['entry_originator'];
						
						/* STEP 2: CHECK FOR ACCURACY */
						if($entry_name==""){$error_console.="You must provide a creative name.<br />";}
						if($entry_type==""){$error_console.="You must tell me what type of video this is.<br />";}
						if($entry_source==""){$error_console.="You must provide a source for the video.<br />";}
						if($entry_originator==""){$error_console.="You must tell me who this video came from.<br />";}
						
						if($error_console != ""){
							/* ERRORS AMONG US! */
							echo "<div class=\"admin-response-error\">".$error_console."</div><div class=\"admin-response-tools\"><a onclick=\"history.go(-1)\" style=\"cursor:pointer;\">Go Back</a></div>";
						} else {
							/* NO ERRORS; YAY!!! */
							echo "<div class=\"admin-response-success\">The entry has been successfully saved!</div><div class=\"admin-response-tools\"><a href=\"".$properties->WEB_URL."?page=admin\" style=\"cursor:pointer;\">Continue</a></div>";
							
							/* STEP 3: SAVE DATA */
							mysql_query("INSERT INTO {$properties->DB_PREFIX}entries (name,source,originator,type) VALUES ('".$entry_name."','".$entry_source."','".$entry_originator."','".$entry_type."')");
						}
					} else {
						?>
						<form method="post" action="">
							<div class="formLayoutMid">
								<div class="formLayoutMidRow">
									<div class="formLayoutMidRowLeftCol">
										 <label>Name</label>
									</div>
									<div class="formLayoutMidRowRightCol">
										<input type="text" name="entry_name">
									</div>
								</div>
								
                                <div class="formLayoutMidRow">
									<div class="formLayoutMidRowLeftCol">
										 <label>Originator</label>
									</div>
									<div class="formLayoutMidRowRightCol">
										<input type="text" name="entry_originator">
									</div>
								</div>
                                
								<div class="formLayoutMidRow">
									<div class="formLayoutMidRowLeftCol">
										<label>Type</label>            
									</div>
									<div class="formLayoutMidRowRightCol">
										<select name="entry_type">
											<option value="youtube">Youtube</option>
											<option value="vimeo">Vimeo</option>
										</select>
									</div>
								</div>
								
								<div class="formLayoutMidRow">
									<div class="formLayoutMidRowLeftCol">
										<label>Source</label>
									</div>
									<div class="formLayoutMidRowRightCol">
										<input type="text" name="entry_source">
									</div>
								</div>
								
								<div class="formLayoutMidRow">
									<div class="formLayoutMidRowLeftCol">
										
									</div>
									<div class="formLayoutMidRowRightCol">
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="entry_save" value="Save">
									</div>
								</div>
								
								<div class="formLayoutMidRow">
									<div class="formLayoutMidRowLeftCol">
										
									</div>
									<div class="formLayoutMidRowRightCol">
										
									</div>
								</div>
							</div>
						</form>
						<?php
					}
					?>
					<?php	
				}
			} else {
				?>
                <h1><a href="<?php echo $properties->WEB_URL;?>" style="text-decoration:none;"> < </a> <a href="<?php echo $properties->WEB_URL;?>?page=admin"><?php echo $properties->TITLE;?>'s Administration Panel</a></h1>
				You must be logged in to use this feature.
				<hr>
				<center>
					<h1><a href="<?php echo $properties->WEB_URL;?>?page=admin">Login</a></h1>
					<?php
					if(isset($_POST['login'])){
						?>
						<form method="POST" action="">
							<div class="formLayout">
								<div class="formLayoutRow">
									<div class="formLayoutRowLeftCol">
										<label>Username</label>
										<input type="text" name="admin_username" disabled="disabled">
										<br />
										<label>Password</label>
										<input type="password" name="admin_password" disabled="disabled">
									</div>
									<div class="formLayoutRowRightCol">
										<input type="submit" name="login" value="Login" disabled="disabled">
									</div>
								</div>
							</div>
						</form>
						<?php
						/* STEP 1: GET POST DATA */
						$username=$_POST['admin_username'];
						$password=$_POST['admin_password'];

						/* STEP 2: CHECK FOR ACCURACY */
						$error_console="";
						if($username == ""){$error_console.="Username must not be blank<br />";}
						if($password == ""){$error_console.="Password must not be blank<br />";}
						
						/* FIND OUT IF USER IS IN DB */
						$DETECT_USER_IN_DB=mysql_query("SELECT * FROM {$properties->DB_PREFIX}admins WHERE uname='$username'");
						if(mysql_num_rows($DETECT_USER_IN_DB)<1){
							/* USER DOES NOT EXIST */
							if($username==""){/* DONT DISPLAY SINCE THEY DID NOT PROVIDE */}else{$error_console.="<b>".$username."</b> does not exist!<br />";}
						} else {
							/* USER EXISTS; CHECK FOR PASSWORD */
							while($FETCH_USER_PASSWORD=mysql_fetch_array($DETECT_USER_IN_DB)){
								$real_password=$FETCH_USER_PASSWORD['upass'];
							}
							if(hash("sha256",sha1(md5($password))) == $real_password){
								/* PASSWORD CHECKS OUT; CHECK FOR STATUS */
								while($FETCH_DETECT_USER_IN_DB=mysql_fetch_array($DETECT_USER_IN_DB)){
									@$status=$FETCH_DETECT_USER_IN_DB['status'];
								}
								switch(@$status){
									case 'active':
										/* USER IS ACTIVE */
										$error_console.="";
									break;
									
									case 'suspended':
										/* USER IS SUSPENDED */
										$error_console.="Your account has been suspended.<br />";
									break;
									
									case 'deleted':
										/* USER DOES NOT EXIST */
										$error_console.="The account you specified does not exist.<br />";
									break;
									
									case 'pending':
										/* USER IS PENDING */
										$error_console.="Your account is still pending.<br />";
									break;
								}
							} else {
								/* PASSWORD FAILED; ERROR */
								if($password==""){/* DON'T MAKE ERROR; THEY DIDN'T PROVIDE PASS */}else{$error_console.="The password you provided is incorrect.<br />";}	
							}
						}
						
						if($error_console != ""){
							/* ERRORS AMONG US! */
							echo "<div class=\"admin-response-error\">".$error_console."</div><div class=\"admin-response-tools\"><a onclick=\"history.go(-1)\" style=\"cursor:pointer;\">Go Back</a></div>";
						} else {
							/* NO ERRORS; YAY!!! */
							echo "<div class=\"admin-response-success\">You have been successfully logged in!</div><div class=\"admin-response-tools\"><a href=\"".$properties->WEB_URL."?page=admin\" style=\"cursor:pointer;\">Continue</a></div>";
							
							/* STEP 3: CREATE SESSION */
							$adminsession=str_shuffle($ip.rand("000000000000000","999999999999999"));
							setcookie("vv_admin_session",$adminsession,time()+(20 * 365 * 24 * 60 * 60));
							
							/* STEP 4: POST UPDATE */
							mysql_query("UPDATE {$properties->DB_PREFIX}admins SET logged_in='yes' WHERE uname='$username'");
							mysql_query("UPDATE {$properties->DB_PREFIX}admins SET logged_ip='$ip' WHERE uname='$username'");
							mysql_query("UPDATE {$properties->DB_PREFIX}admins SET logged_session='$adminsession' WHERE uname='$username'");
						}
						?>
						<?php
					} else {
						?>
						<form method="POST" action="">
							<div class="formLayout">
								<div class="formLayoutRow">
									<div class="formLayoutRowLeftCol">
										<label>Username</label>
										<input type="text" name="admin_username">
										<br />
										<label>Password</label>
										<input type="password" name="admin_password">
									</div>
									<div class="formLayoutRowRightCol">
										<input type="submit" name="login" value="Login">
									</div>
								</div>
							</div>
						</form>
						<?php
					}
					?>
				</center>
				<?php
			}
		break;

		default:
			echo "I think something is broke or someone is trying to hack us therefore I was not able to show you anything. :)";
			echo "<br />";
			echo "<a href=\"".$properties->WEB_URL."\">Go Back</a>";
		break;
	}
} else {
	?>
	<h1><a href="<?php echo $properties->WEB_URL;?>"><?php echo $properties->TITLE;?></a></h1>
	<table cols="4">
		<tr>
	    	<?php
			/* CREATING THE DYNAMIC VARS FOR ENTRIES */
			$FIND_ALL_ENTRIES=mysql_query("SELECT * FROM {$properties->DB_PREFIX}entries WHERE status='active' ORDER BY id");
			if(mysql_num_rows($FIND_ALL_ENTRIES)<1){
				echo "No Video Entries were found. :(";
				$can_vote="no";
			} else {
				while($FETCH_ALL_ENTRIES=mysql_fetch_array($FIND_ALL_ENTRIES)){
					$id=$FETCH_ALL_ENTRIES['id'];
					$name=$FETCH_ALL_ENTRIES['name'];
					$sources=$FETCH_ALL_ENTRIES['source'];
					$type=$FETCH_ALL_ENTRIES['type'];
					$totalvotes=$FETCH_ALL_ENTRIES['totalvotes'];
					?>
	                <td>
	                	<center><?php if(strlen($name)>21){echo "<a title=\"".$name."\" style=\"cursor:help;\">".substr($name,0,21)."..."."</a>";}else{echo $name;}?></center>
	                <div id='mediaplayer_finalists_<?php echo $id;?>'></div>
	                <center>
	                	<?php
						if($properties->RATING_STYLE=="stars"){
							?>
	                        <div class="vote_<?php echo $id;?>" data-average="10" data-id="<?php echo $id;?>" style="text-align:left;"></div>
	                        <?php
						} else if($properties->RATING_STYLE=="radio") {
							?>
	                        <script type="text/javascript">
							$('#vote').click( function() {
								$.ajax({
									url: 'parsing/php/radio.php',
									type: 'post',
									dataType: 'json',
									data: $('form#vote').serialize(),
									success: function(data) {
										alert(html(response));
										$("#vote-result").slideUp(300).delay(1600).fadeIn("slow")	
									}
								});
							});
							</script>
							<form id="vote">
								<input type="radio" class="vote" name="vote" id="vote" value="<?php echo $id;?>" />
							</form>
							<?php
						}
						?>
	                </center>
	                </td>
	                <?php
				}
			}
			?>
	    </tr>
	</table>
	<script type="text/javascript">
	  <?php  
	  $FIND_ALL_ENTRIES=mysql_query("SELECT * FROM {$properties->DB_PREFIX}entries WHERE status='active' ORDER BY id");
	  while($FETCH_ALL_ENTRIES=mysql_fetch_array($FIND_ALL_ENTRIES)){
		$id=$FETCH_ALL_ENTRIES['id'];
		$name=$FETCH_ALL_ENTRIES['name'];
		$source=$FETCH_ALL_ENTRIES['source'];
		$type=$FETCH_ALL_ENTRIES['type'];
		$totalvotes=$FETCH_ALL_ENTRIES['totalvotes'];
		?>
		jwplayer('mediaplayer_finalists_<?php echo $id;?>').setup({
			'flashplayer': 'js/JWPlayer/jwplayer.swf',
			'id': 'playerID',
			'width': '220',
			'height': '165',
			'file': '<?php if($type=="youtube"){?>http://www.youtube.com/watch?v=<?php echo $source;?><?php }else if($type=="vimeo"){/* HOSTED ON TXW : upload to http://downloadvimeo.com/ and download to the uploads folder */?>uploads/<?php echo $source;?>.mp4<?php }?>',
			'controlbar': 'bottom'
		});
		
		<?php
		/* GET LOGGED VARS */
		if(isset($_COOKIE['vv_session'])){
			$session=$_COOKIE['vv_session'];
			$FIND_SESSION=mysql_query("SELECT * FROM {$properties->DB_PREFIX}who WHERE ip='$ip' AND session='$session'");
			if(mysql_num_rows($FIND_SESSION)<1){
				/* NO SESSION */
				$has_voted_times=0;
				$can_vote="yes";
			} else {
				/* COUNT THE NUMBER OF ENTRIES */
				$NUM_ENTRIES=mysql_num_rows($FIND_ALL_ENTRIES);

				while($FETCH_SESSION=mysql_fetch_array($FIND_SESSION)){
					$has_voted_times=$FETCH_SESSION['has_voted_times'];
					
					if($properties->DAILY_VOTING == "yes"){
						/* DAILY VOTING ACTIVE */
						$lastvote=$FETCH_SESSION['lastvote'];
						
						//break the date
						$lastvote_y=substr($lastvote,0,4);
						$lastvote_m=substr($lastvote,5,2);
						$lastvote_d=substr($lastvote,8,2);
						
						//get today's date
						$today=date("Y-m-d");
						
						//break today's date
						$today_y=substr($today,0,4);
						$today_m=substr($today,5,2);
						$today_d=substr($today,8,2);
						
						//voted times counter
						if(($today_y == $lastvote_y) && ($today_m == $lastvote_m) && ($today_d == $lastvote_d)){/* ALREADY VOTED; DO NOTHING */}else{/* NEW (DAY,MONTH,YEAR); RESET HAS_VOTED_TIMES */mysql_query("UPDATE {$properties->DB_PREFIX}who SET has_voted_times = 0 WHERE ip='".$ip."' AND session='".$session."'");}
					}
					
					if($properties->CAN_VOTE_PER == "once"){
						if($has_voted_times<1){
							$can_vote="yes";
						} else if($has_voted_times>=1){
							$can_vote="no";
						}
					} else if($properties->CAN_VOTE_PER == "amtentries") {
						if($has_voted_times<1){
							$can_vote="yes";
						} else if( ($has_voted_times>0) && ($has_voted_times<$NUM_ENTRIES) ){
							$can_vote="yes";
						} else if($has_voted_times==$NUM_ENTRIES){
							$can_vote="no";
						} else if($has_voted_times>$NUM_ENTRIES){
							$can_vote="no";
						}				
					} else if($properties->CAN_VOTE_PER == "inf") {
						$can_vote="yes";				
					}
				}
			}
		} else {
			$session="";
			$can_vote="yes";
		}

		if($can_vote=="no"){
			/* COMPUTER (USER) ALREADY VOTED */
			?>
			/*$(".vote_<?php echo $id;?>").jRating({
				step: <?php echo $properties->VS_STEP;?>,
				length: <?php echo $properties->VS_LENGTH;?>,
				rateMax: <?php echo $properties->VS_RATEMAX;?>,
				nbRates: <?php echo $properties->VS_NBRATES;?>,
				phpPath: '<?php echo $properties->VS_PARSEPATH;?>',
				onSuccess : function(){
					$("#vote-result").slideUp(300).delay(1600).fadeOut(),
					jSuccess('Success : your rate has been saved :)',{
						HorizontalPosition:'center',
						VerticalPosition:'top',
					}),
					$("#vote-result").slideUp(300).delay(1600).fadeIn("slow")
				},
				onError : function(){
					jError('Error : please retry');
				}
			})
			
			$(".voteavg_<?php echo $id;?>").jRating({
				step: true,
				length: 5,
				rateMax: 5,
				nbRates: 1,
				phpPath: 'parsing/php/jQuery.php'
			})*/
			<?php
		} else if($can_vote=="yes") {
			?>
			$(".vote_<?php echo $id;?>").jRating({
				step: <?php echo $properties->VS_STEP;?>,
				length: <?php echo $properties->VS_LENGTH;?>,
				rateMax: <?php echo $properties->VS_RATEMAX;?>,
				nbRates: <?php echo $properties->VS_NBRATES;?>,
				phpPath: '<?php echo $properties->VS_PARSEPATH;?>',
				onSuccess : function(){
					$("#vote-result").slideUp(300).delay(1600).fadeOut(),
					jSuccess('Success : your rate has been saved :)',{
						HorizontalPosition:'center',
						VerticalPosition:'top',
					}),
					$("#vote-result").slideUp(300).delay(1600).fadeIn("slow")
					<?php
					if($properties->CAN_VOTE_PER == "once"){
						?>
						,$(".vote_1").fadeOut(),
						$(".vote_2").fadeOut(),
						$(".vote_3").fadeOut(),
						$(".vote_4").fadeOut(),
						$(".vote_5").fadeOut()
						<?php
					} else if($properties->CAN_VOTE_PER == "amtentries"){
						/* DONT FADE THEM OUT */
					}
					?>

				},
				onError : function(){
					jError('Error : please retry');
				}
			})
			<?php
		}
		?>
		<?php
	  }
	  ?>
	</script>
	<div id="vote-results"<?php if(mysql_num_rows($FIND_ALL_ENTRIES)<1){?>style="display:none;"<?php }?>>
		<?php
		if($can_vote=="yes"){
			/* LET THE JQ DO THE PARSING AND DISPLAYING */
		} else if ($can_vote=="no") {
			?>
	        <div id="resultsContainer" style="display: <?php if($properties->SHOW_RESULTS_IMM == "yes"){?>inline<?php }else if($properties->SHOW_RESULTS_IMM == "no"){?>none<?php }?>;">
				<?php
	            /* PARSE THE RESULTS SO THEY CAN SEE */
	            $FIND_ALL_ENTRIES1=mysql_query("SELECT * FROM {$properties->DB_PREFIX}stats");
	            while($FETCH_ALL_ENTRIES1=mysql_fetch_array($FIND_ALL_ENTRIES1)){
	                $total_voted=$FETCH_ALL_ENTRIES1['total_voted'];
	            }
	            $FIND_ALL_ENTRIES=mysql_query("SELECT * FROM {$properties->DB_PREFIX}entries WHERE status='active' ORDER BY rate DESC");
	            $pos=0;
	            
	            if($properties->SHOW_RESULTS_IMM == "yes"){$SHOW_RESULTS="inline";}else if($properties->SHOW_RESULTS_IMM == "no"){$SHOW_RESULTS="none";}

	            echo "<div id=\"resultsContainer\" style=\"display: '.$SHOW_RESULTS.'\"><hr><h2>Results</h2><p><div class=\"resultsTable\">";
					echo "<div class=\"rtRow\">
						<div class=\"rtLeftCol bold underline\">
							Video Name
						</div>
						<div class=\"rtRightCol\">
							<div class=\"innerResultsTable\">
								<div class=\"irtRow\">
									<div class=\"irtLeftCol bold underline center\">
										Total Votes (<a title=\"The percent of All voters who voted for this video\" style=\"cursor:pointer;\">%</a>)
									</div>
									<div class=\"irtRightCol bold underline\">
										Position
									</div>
								</div>
							</div>
						</div>
					</div>";

					$FIND_ALL_ENTRIES=mysql_query("SELECT * FROM {$properties->DB_PREFIX}entries WHERE status='active' ORDER BY rate DESC");
					$pos=0;
					while($FETCH_ALL_ENTRIES=mysql_fetch_array($FIND_ALL_ENTRIES)){
						$id=$FETCH_ALL_ENTRIES['id'];
						$name=$FETCH_ALL_ENTRIES['name'];
						$source=$FETCH_ALL_ENTRIES['source'];
						$type=$FETCH_ALL_ENTRIES['type'];
						$totalvotes=$FETCH_ALL_ENTRIES['totalvotes'];
						//if($totalvotes<1){$avg=0;}else{$avg=round($rate / $totalvotes,1);}
						$percentof=round(($totalvotes / $total_voted) * 100);
						$pos++;
						$nameString="";
						if(strlen($name)>37){$nameString=substr($name,0,37)."...";}else{$nameString=$name;}
						echo "
						<div class=\"rtRow\">
						
							<div class=\"rtLeftCol\">".$nameString."</div>
							<div class=\"rtRightCol\">
								<div class=\"innerResultsTable\">
									<div class=\"irtRow\">
										<div class=\"irtLeftCol\">
											
											<div class=\"irtLeftColTable\">
												<div class=\"irtLeftColTableRow\">
													<div class=\"irtLeftColTableRowLeftCol bold\">".$totalvotes."</div>
													<div class=\"irtLeftColTableRowRightCol\">(".$percentof."%)</div>
												</div>
											</div>
											
										</div>
										<div class=\"irtRightCol\">
										#".$pos."
										</div>
									</div>
								</div>
							</div>
						</div>";
					}
					echo "</div></p></div>";            
	            ?>
	        </div>
	        <?php
		}
		?>
	</div>
	<?php
	if(mysql_num_rows($FIND_ALL_ENTRIES)<1){
		/* NOTING */
	} else {
		?>
	    <h2>Rules</h2>
	    You <b>may</b> vote <b><?php if($properties->CAN_VOTE_PER == "once"){?>once<?php }else if($properties->CAN_VOTE_PER == "amtentries"){?>once per entry<?php }else if($properties->CAN_VOTE_PER == "inf"){?>as many times as you want<?php }?></b> <?php if($properties->DAILY_VOTING == "yes"){?> per day<?php }else if($properties->DAILY_VOTING == "no"){?><?php }?>
	    <br />You <b>may</b> <?php if($properties->SHOW_RESULTS_IMM == "no"){?><b>not</b> see the results<?php }else if($properties->SHOW_RESULTS_IMM == "yes"){?> see the results once you vote<?php }?> 
	    <?php	
	}
	
	if($properties->DISP_ADMIN_LINK == "yes"){
		/* DISPLAYING LINK */
		?>
        <hr>
        <a href="?page=admin">Administration Panel</a>
        <?php
	} else if($properties->DISP_ADMIN_LINK == "no") {
		/* NO LINK */
	}
}
?>
</center>
</body>
</html>

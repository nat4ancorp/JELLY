-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 21, 2012 at 09:27 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mts`
--

-- --------------------------------------------------------

--
-- Table structure for table `t_queries`
--

CREATE TABLE IF NOT EXISTS `t_queries` (
  `ticket_id` varchar(300) NOT NULL,
  `contact_name` varchar(100) NOT NULL,
  `contact_email` varchar(100) NOT NULL,
  `poc` int(10) NOT NULL,
  `reason` int(10) NOT NULL,
  `contact_message` longtext NOT NULL,
  `extra_notes` longtext NOT NULL,
  `status` enum('Open','Escalated','Closed') NOT NULL DEFAULT 'Open',
  `dateandtime` datetime NOT NULL,
  `is_searchable` enum('yes','no') NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `t_reasons`
--

CREATE TABLE IF NOT EXISTS `t_reasons` (
  `rcode` int(10) NOT NULL AUTO_INCREMENT,
  `reason` varchar(100) NOT NULL,
  `is_searchable` enum('yes','no') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`rcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `t_staff_types`
--

CREATE TABLE IF NOT EXISTS `t_staff_types` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `t_users`
--

CREATE TABLE IF NOT EXISTS `t_users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `upass` varchar(100) NOT NULL,
  `type` enum('user','writer','mod','admin') NOT NULL,
  `is_searchable` enum('yes','no') NOT NULL DEFAULT 'yes',
  `staff_type` int(10) NOT NULL,
  `poc_code` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

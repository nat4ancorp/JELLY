<?php
//main variables
class properties 
{
//-------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------
//       MTS v. 1.0 - Editables - These are all what you need to customize the MTS to your liking
//-------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------
	//property declaration	
	//main variables
	public $COMPANY_NAME 		 			 = 'Nat4an Corp';
	public $PLATFORM 			 			 = 'Mind Power';
	public $TITLE_B4_PLATFORM 	 			 = " - powered by "; //item found before the platform on title
	public $TITLE_AFTER_PLATFORM 			 = " v. "; //item found after the platform on title
	public $VERSION_CTRL 		 			 = '1.0';
	public $WEBSITE_NAME 		 			 = 'Nat4an';
	public $WEBSITE_SLOGAN					 = 'Modular Ticketing System';	
	public $FORM_TITLE						 = 'Modular Ticket System using FormLayout CSS';
	public $WURL							 = '';
	//SEO STUFF
	public $SITE_DESCRIPTION				 = 'A PHP Ticketing System that you can use to slap into your current site to be used as a contact page or a comment form or what ever else you want to use a ticketing system for. This ticketing system is completely modular, meaning all you have to do is slap it on and change the parameters to fix your configuration. It comes with a generic formLayout CSS Style that can be change via a console into any theme placed in the themes folder, delivers nice autoresponse email notifications to the email of your choice, and you can supply any number and any values of inputs/selects/options/buttons/labels. If you need an autoresponder and don\'t wanna build one, use MTS! If you need a nice comment form for your blog, use MTS! If you need to allow people to contact you, use MTS! MTS also allows users who submit a ticket to have a unique ticket number that they get in an email and they can use to check the status of a ticket. Don\'t remember your ticket number? No worries! MTS also accepts emails as a method of checking the status. There is no limit to what you can do with MTS!';
	public $SITE_AUTHOR					 	 = 'Nathan Smyth';
	public $SITE_KEYWORDS					 = 'mts,modular ticketing system,php,modular,cms ticketing,system,comments,autoresponder,email,form'; 
											   /* THIS IS FOR THE DEFAULT KEYWORDS THAT LOAD INTO THE HOME PAGES. IN ORDER */
											   /* TO CUSTOMIZE THE INDIVIDUAL PAGE KEYWORDS PUT IT INTO THE DB. */
											   /* DO NOT END THIS WITH A "," OR ELSE YOU WILL BREAK IT! */
	//database stuff
	public $DB_HOST							 = 'localhost';
	public $DB_USER							 = 'root'; //remote: "mrnat4an_master" or local: "root"
	public $DB_PASS							 = ''; //remote: "thecreation101" or local: ""
	public $DB_NAME							 = 'mts';
	public $DB_PREFIX						 = 't_';
	
//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------
//       DO NOT EDIT BELOW THIS OR ELSE YOU WILL BREAK IT!!! :)
//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------------------------------------
	
	public function setServerTime(){
		return date_default_timezone_set($this->SERVER_LOCATION); 
	}
	
}

function getPageKeywords($launchpadPN,$page,$properties){
	include 'conf/connect.php';
	@$meta=$_GET['meta'];
	@$launchpad=$_GET['launchpad'];
	if($page == "home"){
		$pageKEYWORDS=$properties->SITE_KEYWORDS;
	} else {
		$CHECK_PAGE=mysql_query("SELECT * FROM {$properties->DB_PREFIX}pages WHERE lp='$launchpadPN' AND page='$page'");
		$FETCH_PAGE=mysql_fetch_array($CHECK_PAGE);
		$pageKEYWORDS=$properties->SITE_KEYWORDS.",".$FETCH_PAGE['pageKEYWORDS'];
	}
	
	//get keywords of blog entry if permalink
	if($meta == "permalink"){
		//its a blog entry
		@$blogtitle=converter($properties,$_GET['title'],'url','from');
		$CHECK_PAGE=mysql_query("SELECT * FROM {$properties->DB_PREFIX}blog_entries WHERE title='$blogtitle'");
		$FETCH_PAGE=mysql_fetch_array($CHECK_PAGE);
		$pageKEYWORDS.=",".$FETCH_PAGE['tags'];
	}
	
	//get keywords of work if permalink
	if(($launchpad == $properties->PADMAIN) && ($page == "work") && ($meta == "permalink") && ($_GET['name'] != "")){
		//its a project
		@$projectname=$_GET['name'];
		$projectname=str_replace("-"," ",$projectname);
		$GET_REAL_NAME=mysql_query("SELECT * FROM {$properties->DB_PREFIX}work_projects WHERE name='$projectname'");
		$FETCH_REAL_NAME=mysql_fetch_array($GET_REAL_NAME);
		@$real_name=$FETCH_REAL_NAME['name'];
		$CHECK_PAGE=mysql_query("SELECT * FROM {$properties->DB_PREFIX}work_projects WHERE name='$real_name'");		
		$FETCH_PAGE=mysql_fetch_array($CHECK_PAGE);
		$pageKEYWORDS.=$FETCH_PAGE['tags'];
	}
	return $pageKEYWORDS;
}
?>